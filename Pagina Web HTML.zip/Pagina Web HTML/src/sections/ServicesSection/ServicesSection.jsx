import React from 'react';
import { motion } from 'framer-motion';
import ServiceCard from '../../components/ServiceCard';
import SectionTitle from '../../components/SectionTitle';
import { servicesData } from '../../data/services';
import styles from './ServicesSection.module.css';

const ServicesSection = () => {
  return (
    <section id="services" className={styles.servicesSection}>
      <div className="container">
        <SectionTitle 
          title="Nuestros Servicios"
          subtitle="Soluciones tecnológicas a tu medida"
        />
        
        <div className={styles.servicesGrid}>
          {servicesData.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <ServiceCard 
                icon={service.icon}
                title={service.title}
                description={service.description}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;