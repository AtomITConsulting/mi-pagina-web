// Importaciones (si usas módulos ES6)
import { initAnalytics } from '../services/analytics.js';
import { loadFeatures } from '../services/api.js';
import Modal from '../components/modal.js';
import Carousel from '../components/carousel.js';

// Configuración inicial
const config = {
    apiBaseUrl: 'https://api.tusitio.com/v1',
    debugMode: process.env.NODE_ENV === 'development'
};

// Clase principal de la aplicación
class App {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initComponents();
        this.initServices();
        this.loadInitialData();
    }

    setupEventListeners() {
        // Menú móvil
        const menuToggle = document.getElementById('menu-toggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', this.toggleMenu);
        }

        // Botón CTA
        const ctaButton = document.getElementById('cta-button');
        if (ctaButton) {
            ctaButton.addEventListener('click', this.handleCtaClick);
        }
    }

    initComponents() {
        // Inicializar componentes UI
        this.modal = new Modal({
            selector: '#main-modal',
            animation: 'fade'
        });

        this.carousel = new Carousel({
            container: '#feature-container',
            items: '.feature-item',
            autoplay: true
        });
    }

    initServices() {
        // Inicializar servicios
        initAnalytics('GA_TRACKING_ID');
    }

    async loadInitialData() {
        try {
            const features = await loadFeatures();
            this.renderFeatures(features);
        } catch (error) {
            console.error('Error loading features:', error);
            this.showError('No se pudieron cargar las características');
        }
    }

    renderFeatures(features) {
        const container = document.getElementById('feature-container');
        if (container) {
            container.innerHTML = features.map(feature => `
                <div class="feature-item">
                    <h3>${feature.title}</h3>
                    <p>${feature.description}</p>
                </div>
            `).join('');
        }
    }

    toggleMenu() {
        const menu = document.getElementById('menu');
        const toggle = document.getElementById('menu-toggle');
        const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
        
        toggle.setAttribute('aria-expanded', !isExpanded);
        menu.classList.toggle('active');
    }

    handleCtaClick() {
        // Lógica para el botón CTA
        this.modal.open({
            title: 'Más información',
            content: 'Contenido adicional aquí...'
        });
    }

    showError(message) {
        // Mostrar mensaje de error al usuario
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        document.body.appendChild(errorElement);
        
        setTimeout(() => {
            errorElement.remove();
        }, 5000);
    }
}

// Iniciar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    const app = new App();
});

// Hacer disponible para debugging
window.app = app;