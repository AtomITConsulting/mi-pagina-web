import React from 'react';
import { motion } from 'framer-motion';
import Header from './components/Header';
import ServiceCard from './components/ServiceCard';
import Footer from './components/Footer';
import { Laptop, Home, Shield, Wifi, Lightbulb, TrendingUp, Users, HelpCircle } from 'lucide-react';
import { FaFacebook, FaLinkedin, FaWhatsapp } from 'react-icons/fa';
import logo from '/assets/Logo New c Letras.jpg'; 

const App = () => {
  const services = [
    {
      icon: Laptop,
      title: 'Outsourcing de Soporte Técnico',
      description: 'Expertos a tu disposición para mantener tus sistemas funcionando sin interrupciones. ¡Deja que los nerds hagan el trabajo pesado!',
    },
    {
      icon: Home,
      title: 'Instalación de Domótica',
      description: 'Convierte tu hogar o negocio en un espacio inteligente. Controla todo desde tu sofá (o desde la playa, si eres de los afortunados).',
    },
    {
      icon: Shield,
      title: 'Seguridad y Control de Accesos',
      description: 'Protege lo que más te importa con nuestras soluciones avanzadas. Ni una mosca se te escapa, ¡a menos que tenga credenciales de acceso!',
    },
    {
      icon: Wifi,
      title: 'Internet de las Cosas (IoT)',
      description: 'Conecta tus dispositivos y haz que hablen entre sí. Tu tostadora y tu refrigerador serán los mejores amigos, ¡y tú el director de orquesta!',
    },
  ];

  const benefits = [
    {
      icon: Lightbulb,
      title: 'Innovación Constante',
      description: 'Accede a las últimas tecnologías y soluciones sin la necesidad de grandes inversiones internas. ¡Siempre un paso adelante!',
    },
    {
      icon: TrendingUp,
      title: 'Optimización de Costos',
      description: 'Reduce gastos operativos y de personal al externalizar servicios clave. ¡Más por menos, como nos gusta!',
    },
    {
      icon: Users,
      title: 'Equipo Especializado',
      description: 'Contarás con un equipo de expertos altamente cualificados en diversas áreas. ¡Tu problema es nuestro pasatiempo favorito!',
    },
    {
      icon: Shield,
      title: 'Mayor Seguridad',
      description: 'Implementamos protocolos y sistemas de seguridad robustos para proteger tus datos y operaciones. ¡Dormirás como un bebé!',
    },
  ];

  const testimonials = [
    {
      quote: 'Atom IT Consulting transformó nuestra infraestructura. Su soporte técnico es inigualable, ¡nunca habíamos estado tan tranquilos!',
      author: 'Ana G., Gerente de Operaciones',
    },
    {
      quote: 'La instalación de domótica en nuestra oficina fue impecable. Ahora todo es más eficiente y moderno. ¡Son unos genios!',
      author: 'Carlos R., Dueño de Negocio',
    },
    {
      quote: 'Gracias a Atom IT, nuestra seguridad ha mejorado drásticamente. Su atención al detalle y profesionalismo son de primera.',
      author: 'Sofía M., Directora de Seguridad',
    },
    {
      quote: 'El servicio de IoT que nos brindaron es excepcional. Pudimos integrar todos nuestros dispositivos sin problemas y la eficiencia ha aumentado.',
      author: 'Roberto L., CTO de Startup',
    },
    {
      quote: 'Necesitábamos un soporte técnico rápido y eficiente, y Atom IT Consulting superó nuestras expectativas. ¡Altamente recomendados!',
      author: 'Laura P., Administradora de PYME',
    },
    {
      quote: 'La implementación de control de accesos fue clave para nuestra empresa. El equipo de Atom IT fue muy profesional y el resultado es excelente.',
      author: 'Javier S., Gerente de Seguridad',
    },
  ];

  const faqs = [
    {
      question: '¿Qué tipo de empresas pueden beneficiarse de sus servicios?',
      answer: 'Nuestros servicios están diseñados para adaptarse a empresas de todos los tamaños, desde pequeñas startups hasta grandes corporaciones, así como para hogares que buscan soluciones inteligentes y seguras. Si tienes tecnología, nosotros te ayudamos a que funcione mejor.',
    },
    {
      question: '¿Cómo puedo solicitar una cotización?',
      answer: 'Es muy sencillo. Puedes contactarnos a través de nuestro formulario en la sección de Contacto, enviarnos un WhatsApp o llamarnos directamente. Cuéntanos tus necesidades y te prepararemos una propuesta a medida. ¡No mordemos, a menos que sea un cable suelto!',
    },
    {
      question: '¿Qué es el Internet de las Cosas (IoT) y cómo puede beneficiar a mi negocio?',
      answer: 'El IoT conecta dispositivos físicos a internet, permitiéndoles recopilar y compartir datos. Para tu negocio, esto significa mayor automatización, eficiencia operativa, monitoreo en tiempo real y nuevas oportunidades de negocio. Imagina que tus máquinas te avisan antes de que se rompan, ¡es como tener una bola de cristal tecnológica!',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <Header logo={logo} />

      <main className="pt-20">
        {/* Hero Section */}
        <section id="home" className="relative flex items-center justify-center h-screen bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')` }}>
          <div className="absolute inset-0 bg-blue-800/70"></div>
          <div className="relative z-10 text-center text-white px-4">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 leading-tight"
            >
              Tu Socio Tecnológico de Confianza
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-lg md:text-xl lg:text-2xl font-light mb-8 max-w-2xl mx-auto"
            >
              Innovación y eficiencia para tu negocio y hogar.
            </motion.p>
            <motion.a
              href="#contact"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="inline-block bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Contáctanos Ahora
            </motion.a>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12 text-blue-800"
            >
              Nuestros Servicios
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {services.map((service, index) => (
                <ServiceCard
                  key={index}
                  icon={service.icon}
                  title={service.title}
                  description={service.description}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section id="benefits" className="py-16 md:py-20 bg-blue-800 text-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12"
            >
              ¿Por Qué Elegirnos?
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={index}
                  className="bg-blue-700 rounded-xl shadow-lg p-6 md:p-8 flex flex-col items-center text-center border border-blue-600 hover:shadow-xl transition-all duration-300"
                  whileHover={{ y: -5, scale: 1.02 }}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="p-3 md:p-4 bg-blue-500 rounded-full mb-4 md:mb-6">
                    <benefit.icon className="w-8 h-8 md:w-10 md:h-10 text-white" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3">{benefit.title}</h3>
                  <p className="text-sm md:text-base leading-relaxed text-blue-100">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-16 md:py-20 bg-gray-50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12 text-blue-800"
            >
              Lo Que Dicen Nuestros Clientes
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  className="bg-white rounded-xl shadow-lg p-6 md:p-8 border border-gray-200"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                >
                  <p className="text-base md:text-lg italic mb-4 md:mb-6 text-gray-700">"{testimonial.quote}"</p>
                  <p className="font-semibold text-blue-700">- {testimonial.author}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-16 md:py-20 bg-blue-800 text-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12"
            >
              Preguntas Frecuentes
            </motion.h2>
            <div className="max-w-3xl mx-auto space-y-4 md:space-y-6">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  className="bg-blue-700 rounded-xl shadow-lg p-5 md:p-6 border border-blue-600"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3 flex items-center">
                    <HelpCircle className="w-5 h-5 md:w-6 md:h-6 mr-2 md:mr-3 text-blue-300" />
                    {faq.question}
                  </h3>
                  <p className="text-sm md:text-base text-blue-100">{faq.answer}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12 text-blue-800"
            >
              Contáctanos
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="bg-white rounded-xl shadow-lg p-6 md:p-8"
              >
                <h3 className="text-xl md:text-2xl font-semibold mb-4 md:mb-6 text-blue-800">Información de Contacto</h3>
                <div className="space-y-3 md:space-y-4">
                  <p className="flex items-center text-gray-700">
                    <FaWhatsapp className="w-5 h-5 md:w-6 md:h-6 mr-2 md:mr-3 text-blue-600" />
                    <a href="https://wa.me/525528469656" target="_blank" rel="noopener noreferrer" className="hover:underline">
                      +52 55 2846 9656 (WhatsApp)
                    </a>
                  </p>
                  <p className="flex items-center text-gray-700">
                    <FaFacebook className="w-5 h-5 md:w-6 md:h-6 mr-2 md:mr-3 text-blue-600" />
                    <a href="https://www.facebook.com/AtomITConsulting.mx" target="_blank" rel="noopener noreferrer" className="hover:underline">
                      Facebook
                    </a>
                  </p>
                  <p className="flex items-center text-gray-700">
                    <FaLinkedin className="w-5 h-5 md:w-6 md:h-6 mr-2 md:mr-3 text-blue-600" />
                    <a href="https://www.linkedin.com/company/atom-it-consulting-mexico/" target="_blank" rel="noopener noreferrer" className="hover:underline">
                      LinkedIn
                    </a>
                  </p>
                  <p className="text-gray-700">
                    <span className="font-semibold block mb-1 md:mb-2">Dirección:</span>
                    Nicolas San Juan 553, Del Valle, Benito Juárez, 03100, CDMX, México
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden"
              >
                <h3 className="text-xl md:text-2xl font-semibold p-6 md:p-8 pb-0 text-blue-800">Nuestra Ubicación</h3>
                <div className="w-full h-80 md:h-96">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3763.4000000000002!2d-99.17300000000001!3d19.391000000000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1ff7f0f0f0f0f%3A0x0f0f0f0f0f0f0f0f!2sNicolas%20San%20Juan%20553%2C%20Del%20Valle%2C%20Benito%20Ju%C3%A1rez%2C%2003100%20Ciudad%20de%20M%C3%A9xico%2C%20CDMX%2C%20M%C3%A9xico!5e0!3m2!1ses-419!2smx!4v1678901234567!5m2!1ses-419!2smx"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Ubicación de Atom IT Consulting"
                  ></iframe>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default App;