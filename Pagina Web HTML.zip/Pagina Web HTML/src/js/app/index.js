import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import reportWebVitals from './reportWebVitals';

// Configuración del contenedor raíz
const container = document.getElementById('root');
const root = createRoot(container);

// Renderizado principal
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Medición de performance (opcional)
reportWebVitals();