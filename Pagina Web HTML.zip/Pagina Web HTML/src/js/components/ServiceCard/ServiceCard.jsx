import React from 'react';
import { motion } from 'framer-motion';
import styles from './ServiceCard.module.css';

const ServiceCard = ({ icon: Icon, title, description }) => {
  return (
    <motion.div 
      className={styles.serviceCard}
      whileHover={{ y: -5, scale: 1.02 }}
    >
      <div className={styles.iconContainer}>
        <Icon className={styles.icon} />
      </div>
      <h3 className={styles.title}>{title}</h3>
      <p className={styles.description}>{description}</p>
    </motion.div>
  );
};

export default ServiceCard;