import React from 'react';
import { motion } from 'framer-motion';

const BlogPostCard = ({ post, index }) => {
  return (
    <motion.div
      key={post.id}
      className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: index * 0.15 }}
    >
      <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2 text-primary">{post.title}</h3>
        <p className="text-sm text-gray-500 mb-4">{post.date}</p>
        <p className="text-gray-700 mb-4">{post.excerpt}</p>
        <a href={post.link} className="text-secondary hover:text-accent font-medium flex items-center">
          Leer más
          <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
        </a>
      </div>
    </motion.div>
  );
};

export default BlogPostCard;