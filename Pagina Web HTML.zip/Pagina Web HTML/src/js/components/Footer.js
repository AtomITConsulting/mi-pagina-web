import React from 'react';
import { motion } from 'framer-motion';
import { FaFacebook, FaLinkedin, FaWhatsapp } from 'react-icons/fa';

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.8 }}
      className="bg-gray-800 text-white py-10"
    >
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl font-bold mb-4">Atom IT Consulting</h2>
        <p className="text-gray-400 mb-6">Soluciones tecnológicas innovadoras para tu negocio.</p>

        <div className="flex justify-center space-x-6 mb-8">
          <a
            href="https://www.facebook.com/AtomITConsulting.mx"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-blue-500 transition-colors duration-300"
          >
            <FaFacebook size={30} />
          </a>
          <a
            href="https://www.linkedin.com/company/atom-it-consulting-mexico"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-blue-500 transition-colors duration-300"
          >
            <FaLinkedin size={30} />
          </a>
          <a
            href="https://wa.me/525528469656"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-green-500 transition-colors duration-300"
          >
            <FaWhatsapp size={30} />
          </a>
        </div>

        <div className="text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Atom IT Consulting. Todos los derechos reservados.</p>
          <p>Nicolas San Juan 553, Del Valle, Benito Juárez, 03100, CDMX, México</p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;