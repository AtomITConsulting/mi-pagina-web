import { Laptop, Home, Shield, Wifi } from 'lucide-react';

export const servicesData = [
  {
    id: 'srv-1',
    icon: Laptop,
    title: 'Outsourcing de Soporte Técnico',
    description: 'Expertos a tu disposición para mantener tus sistemas funcionando sin interrupciones...'
  },
  {
    id: 'srv-2',
    icon: Home,
    title: 'Instalación de Domótica',
    description: 'Convierte tu hogar o negocio en un espacio inteligente...'
  },
  {
    id: 'srv-3',
    icon: Shield,
    title: 'Seguridad y Control de Accesos',
    description: 'Protege lo que más te importa con nuestras soluciones avanzadas...'
  },
  {
    id: 'srv-4',
    icon: Wifi,
    title: 'Internet de las Cosas (IoT)',
    description: 'Conecta tus dispositivos y haz que hablen entre sí...'
  }
];